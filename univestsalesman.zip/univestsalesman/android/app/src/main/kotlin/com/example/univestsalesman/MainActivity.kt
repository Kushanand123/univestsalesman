package com.example.univestsalesman

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
