import 'package:flutter/material.dart';
import 'package:dropdownfield/dropdownfield.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Dropdown extends StatefulWidget {
  @override
  _DropdownState createState() => _DropdownState();
}

class _DropdownState extends State<Dropdown> {
List data;

List userData;

// Future<List> fetchUsers() async{
//  String url =   "https://dashboard.univest.com.sa/public/api/getcustomers";
//  http.Response response = await http.get(url,
//    headers: {'Accept': 'Application/json'},
//  );
// data = json.decode(response.body)['name']['success'];
// print('My name list is $data');
// return userData;
// }

//Exception
 //Unhandled Exception: type 'String' is not a subtype of type 'int' of 'index'
@override
void initState() {
  
    super.initState();
    fetchUsers();
  }
  
  final String apiUrl =
      "https://dashboard.univest.com.sa/public/api/getcustomers";
  Future<UserDetails> fetchUsers() async {
    var result = await http.get(apiUrl);
var response   = json.decode(result.body)['sucess']['name'];
print(response );

  }
  String _name(dynamic user) {
    return user['name'];
  }
    final customerSelected = TextEditingController();
  String selectCustomer = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
      child: Container(
        // child: Center(
        //   //  child: FutureBuilder<List<dynamic>>(
        //   //       future: fetchUsers(),
        //   //       builder: (BuildContext context, AsyncSnapshot snapshot) {
        //   //         if (snapshot.hasData) {
        //   //           //  print(_age(snapshot.data[0]));
        //   //           return
        //           child:        DropDownField(
        //               controller : customerSelected,
        //             hintText: 'Cities',
        //               hintStyle: TextStyle(color: Colors.black),
        //               textStyle: TextStyle(fontSize: 18, color: Colors.grey[600]),
        //               enabled: true,
        //               items: fetchUsers()
                   
        //               //required: true,
        //             //  strict: true,
        //               onValueChanged: (value){
        //                 setState(() {
        //                   selectCustomer = value;
        //                 });
        //               },
        //                //   value: selectCity,
        //             )
        //             //}}
        //             )
        )
      ),
    );
  }
}

class UserDetails {
 
  final String name ;


  UserDetails({ this.name, });

  factory UserDetails.fromJson(Map<String, dynamic> json) {
    return new UserDetails(
 
      name: json['name'],

    );
  }
}